
let firstName = document.forms["Register"]["firstName"];

let lastName = document.forms["Register"]["lastName"];

let userName = document.forms["Register"]["email"];
let password = document.forms["Register"]["password"];
let confirmPassword = document.forms["Register"]["confirmPassword"];

let mobileNumber = document.forms["Register"]["phoneno"];

let ul = document.getElementById("errorsList");

var phoneno = /^\d{10}$/;

let isSuccess = true ;

function addErrorItem (errorMessage){
    isSuccess = false ;
    var li = document.createElement("li");
    li.appendChild(document.createTextNode(errorMessage));
    ul.appendChild(li);
}

function checkIfEmpty(item) {
    if (item.value == ""){
        addErrorItem('The ' +item.name +' have a value.')
    }
  }

function checkIfAllControlsNotEmpty(){
    let controlsList  = document.getElementsByTagName('input');
    let inputList = Array.prototype.slice.call(controlsList);
    inputList.forEach(checkIfEmpty);
}


function checkNameifOnlyAlphabets(){
    let checkFirstName = /^[a-zA-Z\s]+$/.test(firstName.value);
    let checklastName = /^[a-zA-Z\s]+$/.test(lastName.value);


    if (!checkFirstName) {
        addErrorItem('The first name must contains alphabets only.')
    }

    if (!checklastName) {
        addErrorItem('The Last name must contains alphabets only.')
    }
   
}

function checkLengthOfPassword(){
        if (password.value.length < 8){
            addErrorItem('The Password must be equal or greater than 8 characters.')
        }
}


function checkPasswordMatch(){
    
    if (password.value !== confirmPassword.value){
        addErrorItem('The Password and confirm Password doesnt match.')
    }

}

function checkMobileNumber(){

    let checkMobileNumber = /^\d{10}$/.test(mobileNumber.value);

    if (!checkMobileNumber) {
        addErrorItem('The phone no  must contains 10 digits only.')
    }

}


function validateForm () {
    document.getElementById("errorsList").innerHTML = "";
    checkIfAllControlsNotEmpty() ;
    checkNameifOnlyAlphabets() ;
    checkLengthOfPassword() ;
    checkPasswordMatch() ;
    checkMobileNumber();
    if (isSuccess){
       alert("Success...Thank you for submit the Form!!");
    }

  }




  
  