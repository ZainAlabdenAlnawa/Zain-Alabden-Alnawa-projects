
<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->role <= 2): ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;"><?php echo e(__('Add Articles')); ?></div>
                </center>
                <form method="post" action="artsstore">
                <?php echo e(csrf_field()); ?>

                    <div class="input-group">
                    <hr>
                <div class="d-grid gap-2 col-6 mx-auto">
                  <br>
                        <input type="file" name="path" class="form-control" placeholder="Add photo...">
                        <hr>
                        <input type="text" name="title" class="form-control" placeholder="Add title...">   
                        <hr>
                        <input type="text" name="provider" class="form-control" placeholder="Add provider...">   
                        <hr>          
                       <input type="text" name="text" class="form-control" placeholder="Add text...">      
                       <hr>              
                       <button class="btn btn-outline-primary" style="font-size:20px" type="submit">Add</button>
                        <hr>
                    </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

 <section class="bg-light py-4 my-5" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <h2 style="color:#FF0000 ; font-family: cursive;">Read and enjoy...!</h2>
            </center>
            <div class="container shadow mt-5 border" >
                 <div class="row">
                     <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="col-md-6 col-lg-4">
                         <div class="card my-3">
                             <div class="card-thumbnail">
                                 <img src="img/<?php echo e($article->path); ?>" class="img-fluid imges"  alt="article1">
                                </div>
                                <div class="card-body">  
                                    <h5 class="card-title" style="color:#FF0000 ; font-family: cursive;"><?php echo e($article->title); ?></h5>
                                    <p class="card-text"><?php echo e($article->provider); ?></p>
                                    <center>
                                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal<?php echo e($article->id); ?>">View</button>
                                        <?php if(Auth::user()->role <= 2): ?>
                                        <a href="/articles/<?php echo e($article->id); ?>/adelete" class="btn btn-danger">Delete</a>
                                        <a href="/articles/<?php echo e($article->id); ?>/aedit" class="btn btn-info">Edit</a>
                                        <?php endif; ?>
                                        <div class="modal" id="myModal<?php echo e($article->id); ?>">
                                            <div class="modal-dialog">
                                                <div class="modal-content" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" style="color:#FF0000 ;"><?php echo e($article->title); ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <img src="img/<?php echo e($article->path); ?>" class="img-fluid imges"  alt="article1">    
                                                    </div>
                                                    <div class="mb-3">
                                                        <P> <?php echo e($article->text); ?></p>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <p style="color:#FF0000 ;" class="card-text"><?php echo e($article->provider); ?></p>
                                                </div>
                                            </center>
                                        </div>  
                                    </div>    
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sem 8\project\xampp\htdocs\DHOOM-DL\resources\views/articles.blade.php ENDPATH**/ ?>