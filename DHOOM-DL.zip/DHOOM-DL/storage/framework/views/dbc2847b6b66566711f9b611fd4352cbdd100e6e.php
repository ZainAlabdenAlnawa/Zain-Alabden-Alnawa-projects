

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;"><?php echo e(__('Assignments')); ?></div>
                </center>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Subject Name</th>
                                <th>File</th>
                                <th>Comment</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($assignment->yname); ?></td>
                                <td><?php echo e($assignment->sname); ?></td>
                                <td><?php echo e($assignment->file); ?></td>
                                <td><?php echo e($assignment->text); ?></td>
                                <td><a href="/assignments/<?php echo e($assignment->id); ?>/assdelete" class="btn btn-danger">delete</a></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sem 8\project\xampp\htdocs\DHOOM-DL\resources\views/assignments.blade.php ENDPATH**/ ?>