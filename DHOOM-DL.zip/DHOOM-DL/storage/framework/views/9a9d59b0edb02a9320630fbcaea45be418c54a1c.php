
<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->role <= 2): ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;"><?php echo e(__('Add course')); ?></div>
                </center>
                <form method="post" action="../<?php echo e($type->id); ?>/coursesstore">
                <?php echo e(csrf_field()); ?>

                    <div class="input-group">
                    <hr>
                <div class="d-grid gap-2 col-6 mx-auto">
                  <br>
                        <input type="file" name="path" class="form-control" placeholder="Add photo...">
                        <hr>
                        <input type="text" name="title" class="form-control" placeholder="Add title...">   
                        <hr>     
                       <input type="text" name="text" class="form-control" placeholder="Add text...">      
                       <hr>              
                       <button class="btn btn-outline-primary" style="font-size:20px" type="submit">Add</button>
                        <hr>
                    </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>


<section class="bg-light py-4 my-5" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                  <h2 style="color:#FF0000 ; font-family: cursive;"><?php echo e($type->title); ?></h2>
                  </center>
      <div class="container shadow mt-5 border">
      <div class="row">
        <?php $__currentLoopData = $type->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="<?php echo e(URL::to('/img/' . $course->path)); ?>" class="img-fluid imges"  alt="course photo">
                </div>
                <div class="card-body" >  
                  <h3 class="card-title" style="color:#FF0000 ; font-family: cursive;"><?php echo e($course->title); ?></h3>
                      <p class="card-text"><?php echo e($course->text); ?></p>
                      <center>
                        <div class="dropdown">
                          <button class="btn btn-primary dropdown-toggle" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown" aria-expanded="false">
                            Start learn
                          </button>
                          <ul class="dropdown-menu dropdown-menu-primary" aria-labelledby="dropdownMenuButton2">
                            <li><a class="dropdown-item" data-bs-toggle="offcanvas" href="#offcanvasExample">DHOOM WAY</a></li>
                            <li><a class="dropdown-item" href="#">Videos</a></li>
                            <li><a class="dropdown-item" href="#">Theory</a></li>
                          </ul>
                        </div>
                      </center>
                       </div>  
                     </div>    
                   </div>
                


<div class="offcanvas offcanvas-start" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
  <div class="offcanvas-header">
    <h5 class="offcanvas-title" id="offcanvasExampleLabel" style="color: #FF0000 ; font-weight:bold;">DHOOM WAY</h5>
    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
  </div>
  <div class="offcanvas-body">
    <div>
      <p style="font-weight: bold;">Here we want you to start in a way that takes the most benefit possible.<br><br>All you have to do is start in the given order.<br><br>We wish you good luck and an enjoyable education.
    </div>
    <div class="dropdown mt-3">
      <button  class="btn btn-info dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" 
      style="width:170px">First section</button>
      <ul class="dropdown-menu dropdown-menu-primary" aria-labelledby="dropdownMenuButton">
        <li><a class="dropdown-item" href="#">video-1</a></li>
        <li><a class="dropdown-item" href="#">theory-1</a></li>
        <li><a class="dropdown-item" href="#">video-2</a></li>
        <li><a class="dropdown-item" href="#">theory-2</a></li>
        <li><a class="dropdown-item" href="#">video-3</a></li>
        <li><a class="dropdown-item" href="#">theory-3</a></li>
        <li><a class="dropdown-item" href="#">video-4</a></li>
        <li><a class="dropdown-item" href="#">theory-4</a></li>
        <li><a class="dropdown-item" href="#">video-5</a></li>
        <li><a class="dropdown-item" href="#">theory-5</a></li>
        <li><a class="dropdown-item" href="#">First Quiz</a></li>
      </ul>
    </div>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>
                </div>
                </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sem 8\project\xampp\htdocs\DHOOM-DL\resources\views/onetype.blade.php ENDPATH**/ ?>