
<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->role <= 2): ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;"><?php echo e(__('Edit Articles')); ?></div>
                </center>
                <form method="post" action="aupdate">
                <?php echo e(csrf_field()); ?>

                    <div class="input-group">
                    <hr>
                <div class="d-grid gap-2 col-6 mx-auto">
                  <br>
                        <input type="file" name="path" value="<?php echo e($Article->path); ?>" class="form-control" placeholder="Add photo...">
                        <hr>
                        <input type="text" name="title" value="<?php echo e($Article->title); ?>" class="form-control" placeholder="Add title...">   
                        <hr>
                        <input type="text" name="provider" value="<?php echo e($Article->provider); ?>" class="form-control" placeholder="Add provider...">   
                        <hr>          
                       <input type="text" name="text" value="<?php echo e($Article->text); ?>" class="form-control" placeholder="Add text...">      
                       <hr>              
                       <button class="btn btn-outline-primary" style="font-size:20px" type="submit">Edit</button>
                        <hr>
                    </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sem 8\project\xampp\htdocs\DHOOM-DL\resources\views/aedit.blade.php ENDPATH**/ ?>