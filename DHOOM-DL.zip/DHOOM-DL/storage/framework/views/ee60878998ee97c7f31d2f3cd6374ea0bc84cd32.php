
<?php $__env->startSection('content'); ?>
<section class="bg-light py-4 my-5" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                  <h2 style="color:#FF0000 ; font-family: cursive;">Read and enjoy...!</h2>
                </center>
      <div class="container shadow mt-5 border" >
        <div class="row">
           <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/article1.png" class="img-fluid imges"  alt="article1">
                </div>
                <div class="card-body">  
                  <h5 class="card-title" style="color:#FF0000 ; font-family: cursive;">How did the idea of Dhoom came?</h5>
                      <p class="card-text">By: Zain Alabden Alnawa</p>
                       <center>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal4">
                         View</button>
                       <div class="modal" id="myModal4">
                        <div class="modal-dialog">
                          <div class="modal-content" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
                            <div class="modal-header">
                              <h5 class="modal-title" style="color:#FF0000 ;">How did the idea of Dhoom came?</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                             <div class="modal-body">
                              
                              <form>
          <div class="mb-3">
            <img src="img/article1.png" class="img-fluid imges"  alt="article1">    
          </div>
          <div class="mb-3">
            <P>
              Many colleges by using Dhoom can be educational institution not only a basic college. Through cooperation, colleges can provide many courses for people interested in advertising a field without the need for a full study program. How did our idea come?  We believe that by joining hands and helping each other, we can advance society to the highest levels. Therefore, through our experiences as students, we can understand what other students think and feel and meet practical and scientific study needs (and what we mean exactly is that our goal is to provide the useful output from each course without having to waste time on unnecessary side things too much).
            </p>
          </div>
        </form>
      </div>
      <div class="modal-footer">
                              <p style="color:#FF0000 ;" class="card-text">By: Zain Alabden Alnawa</p
                          </div>

                      </div>
                    </div>
                  </center>
                       </div>  
                     </div>    
                      </div>
            <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/article2.jpg" class="img-fluid imges" alt="project">
                </div>
                <div class="card-body">  
                  <h5 class="card-title" style="color:#FF0000 ; font-family: cursive;">What are the DHOOM advantages?</h5>
                  <p class="card-text">By: Mohamad Ali Kadon</p>
                      <center>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal3">
                         View</button>
                       <div class="modal" id="myModal3">
                        <div class="modal-dialog">
                          <div class="modal-content" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
                            <div class="modal-header">
                              <h5 class="modal-title" style="color:#FF0000 ;">What are the DHOOM advantages?</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                             <div class="modal-body">
                              
                              <form>
          <div class="mb-3">
            <img src="img/article2.jpg" class="img-fluid imges" style="width:450px; height: 250px;" alt="article2"> 
          </div>
          <div class="mb-3">
            <p>
              DHOOM will teach you and you will teach the world. The advantages of our project are summarized in our slogan, which is that we will educate you as an individual and make you confident in yourself and your acquired knowledge, and in your role as an intelligent and philanthropic person, you will spread knowledge and knowledge to other individuals.  And with our belief in the saying that engineers are the masters of the world, we will provide support to everyone to solve their problems and gain them the right ways of thinking engineer. We want to make you truly feel that you are a capable engineer in every sense of the word.
            </p>
          </div>
        </form>


                            </div>
                            <div class="modal-footer">
                              <p style="color:#FF0000 ;" class="card-text">By: Mohamad Ali Kadon</p
                          </div>
                        </div>
                      </div>
                    </div>
                  </center>
                        
                      </center>
                       </div>
                     </div>
                   </div>
            <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/article3.png" class="img-fluid imges" alt="guid">
                </div>
                <div class="card-body">  
                  <h5 class="card-title" style="color:#FF0000 ; font-family: cursive;">Volunteering in Dhoom</h5>
                  <p class="card-text">By: Ajam Mohammad</p>
                  <center>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal2">
                         View</button>
                       <div class="modal" id="myModal2">
                        <div class="modal-dialog">
                          <div class="modal-content" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
                            <div class="modal-header">
                              <h5 class="modal-title" style="color:#FF0000 ;">Volunteering in Dhoom</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                             <div class="modal-body">
                              
                              <form>
          <div class="mb-3">
            <img src="img/article3.png" class="img-fluid imges"  alt="article3">     
          </div>
          <div class="mb-3">
            <p>
              Whoever sees good, he only sees what is inside himself.  Think the good and it will happen to you, you are the harvest of what you think about all day long. We love to provide goodness to the community and believe that everyone has his own good side, so we decided to add the idea of volunteering to our site, and it is focused that anyone who has skill and knowledge and would like to share it with others will be pleased to provide him with this opportunity and the support he needs in addition to that the volunteer may be able to achieve His personal benefit such as achieving fame among students and being a destination for them in the future.
            </p>
          </div>
        </form>


                            </div>
                            <div class="modal-footer">
                              <p style="color:#FF0000 ;" class="card-text">By: Ajam Mohammad</p
                          </div>
                        </div>
                      </div>
                    </div>
                  </center>
                    </div>  
                  </div>    
                </div>
                <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/article4.jpg" style="height: 230px;" class="img-fluid imges" alt="article">
                </div>
                <div class="card-body">  
                  <h5 class="card-title" style="color:#FF0000 ; font-family: cursive;">Dhoom Support</h5>
                  <p class="card-text">By: Razan Darwich</p>
                      <center>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal1">
                         View</button>
                       <div class="modal" id="myModal1">
                        <div class="modal-dialog">
                          <div class="modal-content" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
                            <div class="modal-header">
                              <h5 class="modal-title" style="color:#FF0000 ;">Dhoom Support</h5>
                              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                             <div class="modal-body">
                              
                              <form>
          <div class="mb-3">
            <img src="img/article5.jpg" class="img-fluid imges" style="height:170px; width:450px; " alt="article4">     
          </div>
          <div class="mb-3">
            <p>
              Everyone will receive support and learning in different ways to suit all minds and people. We will also provide public support for free and what he needs only his own device and the Internet. As for private support for individuals, it will be paid support, but in a symbolic way commensurate with the student situation in addition.  To the level and volume of service required of our team members.  Everyone is aware that any project needs support, especially financial support, and since our idea is largely directed to the student segment, we decided to gain our financial support in ways that do not affect the students, such as creating a YouTube channel and linking it to our site, and thus we earn from the number of views in addition to placing our texts in a blogger and linking it to our site in this way.  We earn from the number of blogger visitors, and as mentioned previously, there is paid private support.
            </p>
          </div>
        </form>


                            </div>
                            <div class="modal-footer">
                              <p style="color:#FF0000 ;" class="card-text">By: Razan Darwich</p
                          </div>
                        </div>
                      </div>
                    </div>
                      </center>
                       </div>
                     </div>
                   </div>
            </div>
          </div>
        </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sem 8\project\xampp\htdocs\DHOOM-DL\resources\views/articels.blade.php ENDPATH**/ ?>