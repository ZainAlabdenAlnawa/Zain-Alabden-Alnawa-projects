

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-4">
            <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;"><?php echo e(__('User profile')); ?></div>
            </center>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <span style="color:blue; font-size: 20px; font-weight: 600;">Username: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  </span> <span style="font-size: 15px; font-weight: 600;"><?php echo e(Auth::user()->name); ?></span>
                    <hr>
                    <span style="color:blue; font-size: 20px; font-weight: 600;">Email: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  </span> <span style="font-size: 15px; font-weight: 600;"><?php echo e(Auth::user()->email); ?></span>
                    <hr>
                    <span style="color:blue; font-size: 20px; font-weight: 600;">Your ID: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  </span> <span style="font-size: 15px; font-weight: 600;"><?php echo e(Auth::user()->id); ?></span>
                    <hr>
                    <span style="color:blue; font-size: 20px; font-weight: 600;">Phone: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  </span> <span style="font-size: 15px; font-weight: 600;"><?php echo e(Auth::user()->phone); ?></span>
                    <hr>
                    <span style="color:blue; font-size: 20px; font-weight: 600;">Country: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  </span> <span style="font-size: 15px; font-weight: 600;"><?php echo e(Auth::user()->country); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sem 8\project\xampp\htdocs\DHOOM-DL\resources\views/Profile.blade.php ENDPATH**/ ?>