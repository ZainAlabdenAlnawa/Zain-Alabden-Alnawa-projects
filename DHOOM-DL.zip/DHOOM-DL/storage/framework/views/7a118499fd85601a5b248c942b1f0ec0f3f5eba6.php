<?php $__env->startSection('content'); ?>
<center>
<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/programming.jpg" width="84%" height="340px" alt="programming">
    </div>
    <div class="carousel-item">
      <img src="img/networking.jpg" width="84%" height="340px" alt="networking">
    </div>
    <div class="carousel-item">
      <img src="img/design.jpg" width="84%" height="340px" alt="Design">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
</center>

<div class="container1">
<div class="button">
	<div class="bfloat">
	<br>
	<a href="<?php echo e(route('login')); ?>"><button type="button" class="btn btn-outline-primary btn-lg" onclick="alert('Please Login first..!!')">COURSES</button></a>
	<a href="<?php echo e(route('login')); ?>"><button type="button" class="btn btn-outline-primary btn-lg" onclick="alert('Please Login first..!!')">SERVICE</button></a>
</div>
  </div>
<div class="container-fluid mt-3">
	<div class="art">
  <h3 style="font-weight: bold;">Hi  , welcome to DHOOM</h3>
  <p style="color:gray"><b>We teach you , and you teach the world.</b></p>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sem 8\project\xampp\htdocs\DHOOM-DL\resources\views/welcome.blade.php ENDPATH**/ ?>