

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;"><?php echo e(__('Users')); ?></div>
                </center>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Country</th>
                                <th>Role</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scop="row"><?php echo e($user->id); ?></th>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->phone); ?></td>
                                <td><?php echo e($user->country); ?></td>
                                <td>
                                    <?php if(Auth::user()->role >=2 || $user->id == 1): ?>
                                    <b>Disabled</b>
                                    <?php else: ?>
                                    <div class="form-group" style="margin-bottom: 0px;">
                                    <form method="post" action="/updaterole/<?php echo e($user->id); ?>">
                                    <?php echo e(csrf_field()); ?>

                                        <select class="form-control" name="role" onchange="this.form.submit();">
                                            <option value="1" <?php echo e(($user->role == 1) ? 'selected' : null); ?>>Admin</option>
                                            <option value="2" <?php echo e(($user->role == 2) ? 'selected' : null); ?>>Coach</option>
                                            <option value="3" <?php echo e(($user->role == 3) ? 'selected' : null); ?>>volunteer</option>
                                            <option value="4" <?php echo e(($user->role == 4) ? 'selected' : null); ?>>User</option>
                                        </select>
                                    </form>
                                </div>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sem 8\project\xampp\htdocs\DHOOM-DL\resources\views/control.blade.php ENDPATH**/ ?>