<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::view("login",'login');
Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/Profile', [App\Http\Controllers\HomeController::class, 'Profile'])->name('Profile');
Route::get('/control', [App\Http\Controllers\HomeController::class, 'control'])->name('control');
Route::get('/controls', [App\Http\Controllers\HomeController::class, 'controls'])->name('controls');
Route::post('/updaterole/{user}', [App\Http\Controllers\HomeController::class, 'updaterole'])->name('updaterole');
Route::get('/aboutus', [App\Http\Controllers\HomeController::class, 'aboutus'])->name('aboutus');
Route::get('/types', [App\Http\Controllers\HomeController::class, 'types'])->name('types');
Route::get('/types/{type}', [App\Http\Controllers\HomeController::class, 'onetype'])->name('onetype');
Route::post('/typesstore', [App\Http\Controllers\HomeController::class, 'typesstore'])->name('typesstore');
Route::post('/types/{type}/coursesstore', [App\Http\Controllers\TypeController::class, 'coursesstore'])->name('coursesstore');
Route::get('/types/{type}/delete', [App\Http\Controllers\HomeController::class, 'typesdelete'])->name('typesdelete');
Route::get('/services', [App\Http\Controllers\HomeController::class, 'services'])->name('services');
Route::get('/articles', [App\Http\Controllers\HomeController::class, 'articles'])->name('articles');
Route::post('/artsstore', [App\Http\Controllers\HomeController::class, 'artsstore'])->name('artsstore');
Route::get('/articles/{Article}/adelete', [App\Http\Controllers\HomeController::class, 'articlesdelete'])->name('articlesdelete');
Route::get('/articles/{Article}/aedit', [App\Http\Controllers\HomeController::class, 'articlesedit'])->name('articlesedit');
Route::post('/articles/{Article}/aupdate', [App\Http\Controllers\HomeController::class, 'articlesupdate'])->name('articlesupdate');
Route::get('/assignments', [App\Http\Controllers\HomeController::class, 'assignments'])->name('assignments');
Route::post('/assstore', [App\Http\Controllers\HomeController::class, 'assstore'])->name('assstore');
Route::get('/assignments/{assignment}/assdelete', [App\Http\Controllers\HomeController::class, 'assdelete'])->name('assdelete');
Route::get('/projects', [App\Http\Controllers\HomeController::class, 'projects'])->name('projects');
Route::post('/prostore', [App\Http\Controllers\HomeController::class, 'prostore'])->name('prostore');
Route::get('/projects/{project}/prodelete', [App\Http\Controllers\HomeController::class, 'prodelete'])->name('prodelete');
Route::get('/guides', [App\Http\Controllers\HomeController::class, 'guides'])->name('guides');
Route::post('/guistore', [App\Http\Controllers\HomeController::class, 'guistore'])->name('guistore');
Route::get('/guides/{guide}/guidelete', [App\Http\Controllers\HomeController::class, 'guidelete'])->name('guidelete');
Route::get('/volus', [App\Http\Controllers\HomeController::class, 'volus'])->name('volus');
Route::post('/volstore', [App\Http\Controllers\HomeController::class, 'volstore'])->name('volstore');
Route::get('/volus/{volu}/voldelete', [App\Http\Controllers\HomeController::class, 'voldelete'])->name('voldelete');
Route::get('/others', [App\Http\Controllers\HomeController::class, 'others'])->name('others');
Route::post('/othstore', [App\Http\Controllers\HomeController::class, 'othstore'])->name('othstore');
Route::get('/others/{other}/othdelete', [App\Http\Controllers\HomeController::class, 'othdelete'])->name('othdelete');

Route::get('/courses/{course}/cedit', [App\Http\Controllers\HomeController::class, 'cedit'])->name('cedit');
Route::post('/courses/{course}/cupdate', [App\Http\Controllers\HomeController::class, 'cupdate'])->name('cupdate');
