@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;">{{ __('Assignments') }}</div>
                </center>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student Name</th>
                                <th>Subject Name</th>
                                <th>File</th>
                                <th>Comment</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($assignments as$assignment)
                            <tr>
                                <td>{{ $assignment->yname }}</td>
                                <td>{{ $assignment->sname }}</td>
                                <td>{{ $assignment->file }}</td>
                                <td>{{ $assignment->text }}</td>
                                <td><a href="/assignments/{{$assignment->id}}/assdelete" class="btn btn-danger">delete</a></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection