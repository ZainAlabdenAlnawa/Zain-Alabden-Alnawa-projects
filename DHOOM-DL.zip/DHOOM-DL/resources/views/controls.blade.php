@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 37px; font-weight: 600; color:#FF0000 ; font-family: cursive;">{{ __('Controls') }}</div>
                </center>
               
<hr>
                <div class="d-grid gap-2 col-6 mx-auto">
  <a href="{{ route('control') }}" class="btn btn-outline-primary" style="font-size:30px">users</a>
  <hr>
  <a href="{{ route('types') }}" class="btn btn-outline-primary" style="font-size:30px">courses</a>
  <hr>
  <a href="{{ route('services') }}" class="btn btn-outline-primary" style="font-size:30px">services</a>
<hr>

</div>

            </div>
        </div>
    </div>
</div>

@endsection