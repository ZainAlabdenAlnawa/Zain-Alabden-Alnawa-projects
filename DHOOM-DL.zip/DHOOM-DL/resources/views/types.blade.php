@extends('layouts.app')
@section('content')

@if(Auth::user()->role <= 2)
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;">{{ __('Add Type') }}</div>
                </center>
                <form method="post" action="typesstore">
                {{ csrf_field() }}
                    <div class="input-group">
                    <hr>
                <div class="d-grid gap-2 col-6 mx-auto">
                  <br>
                        <input type="file" name="path" class="form-control" placeholder="Add photo...">
                        <hr>
                        <input type="text" name="title" class="form-control" placeholder="Add title...">   
                        <hr>     
                       <input type="text" name="text" class="form-control" placeholder="Add text...">      
                       <hr>              
                       <button class="btn btn-outline-primary" style="font-size:20px" type="submit">Add</button>
                        <hr>
                    </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endif


<section class="bg-light py-4 my-5" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                  <h2 style="color:#FF0000 ; font-family: cursive;">Learn Now...!</h2>
                </center>
      <div class="container shadow mt-5 border">
        <div class="row">
        @foreach($types as $types)
           <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/{{$types->path}}" class="img-fluid imges"  alt="course type photo">
                </div>
                <div class="card-body">  
                  <h3 class="card-title" style="color:#FF0000 ; font-family: cursive;">{{$types->title}}</h3>
                      <p class="card-text">{{$types->text}}</p>
                      <center>
                        <a href="/types/{{$types->id}}/" class="btn btn-primary">start</a>
                        @if(Auth::user()->role <= 2)
                        <a href="/types/{{$types->id}}/delete" class="btn btn-danger">delete</a>
                        @endif
                      </center>
                       </div>  
                     </div>    
                      </div>
                      @endforeach
                      </div>
                    </div>
                </div>   
            </section>
            
           


@endsection