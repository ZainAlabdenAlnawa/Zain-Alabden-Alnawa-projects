@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;">{{ __('Users') }}</div>
                </center>
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Country</th>
                                <th>Role</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($users as$user)
                            <tr>
                                <th scop="row">{{ $user->id }}</th>
                                <td>{{ $user->name }}</td>
                                <td>{{ $user->email }}</td>
                                <td>{{ $user->phone }}</td>
                                <td>{{ $user->country }}</td>
                                <td>
                                    @if (Auth::user()->role >=2 || $user->id == 1)
                                    <b>Disabled</b>
                                    @else
                                    <div class="form-group" style="margin-bottom: 0px;">
                                    <form method="post" action="/updaterole/{{ $user->id }}">
                                    {{ csrf_field() }}
                                        <select class="form-control" name="role" onchange="this.form.submit();">
                                            <option value="1" {{ ($user->role == 1) ? 'selected' : null }}>Admin</option>
                                            <option value="2" {{ ($user->role == 2) ? 'selected' : null }}>Coach</option>
                                            <option value="3" {{ ($user->role == 3) ? 'selected' : null }}>volunteer</option>
                                            <option value="4" {{ ($user->role == 4) ? 'selected' : null }}>User</option>
                                        </select>
                                    </form>
                                </div>
                                @endif
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection