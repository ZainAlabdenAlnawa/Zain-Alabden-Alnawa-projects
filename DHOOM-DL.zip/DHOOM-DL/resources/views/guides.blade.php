@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;">{{ __('Guide') }}</div>
                </center>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student or Team Name</th>
                                <th>project Name</th>
                                <th>project Type</th>
                                <th>Abstract & technology </th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($guides as$guide)
                            <tr>
                                <td>{{ $guide->yname }}</td>
                                <td>{{ $guide->pname }}</td>
                                <td>{{ $guide->ptype }}</td>
                                <td>{{ $guide->text }}</td>
                                <td><a href="/guides/{{$guide->id}}/guidelete" class="btn btn-danger">delete</a></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection