@extends('layouts.app')
@section('content')

@if(Auth::user()->role <= 2)
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;">{{ __('Edit Articles') }}</div>
                </center>
                <form method="post" action="aupdate">
                {{ csrf_field() }}
                    <div class="input-group">
                    <hr>
                <div class="d-grid gap-2 col-6 mx-auto">
                  <br>
                        <input type="file" name="path" value="{{ $Article->path }}" class="form-control" placeholder="Add photo...">
                        <hr>
                        <input type="text" name="title" value="{{ $Article->title }}" class="form-control" placeholder="Add title...">   
                        <hr>
                        <input type="text" name="provider" value="{{ $Article->provider }}" class="form-control" placeholder="Add provider...">   
                        <hr>          
                       <input type="text" name="text" value="{{ $Article->text }}" class="form-control" placeholder="Add text...">      
                       <hr>              
                       <button class="btn btn-outline-primary" style="font-size:20px" type="submit">Edit</button>
                        <hr>
                    </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endif

@endsection