@extends('layouts.app')
@section('content')
<section class="bg-light py-4 my-5" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                  <h2 style="color:#FF0000 ; font-family: cursive;">We are here for you...!</h2>
                  <h6 style="color:lightslategray ; font-family: cursive;">Will answer you in the next 24 hours</h6>
                </center>
      <div class="container shadow mt-5 border" >
        <div class="row">
           <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/assignment.jpg" class="img-fluid imges"  alt="Assignment">
                </div>
                <div class="card-body">  
                  <h3 class="card-title" style="color:#FF0000 ; font-family: cursive;">Assignments</h3>
                      <p class="card-text">Will help you to solve yout assignments.</p>
                       <center>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal4">
                         Start</button>
                         @if(Auth::user()->role <= 2)
                        <a href="{{ route('assignments') }}" class="btn btn-warning">View</a>
                        @endif
                       <div class="modal" id="myModal4">
                        <div class="modal-dialog">
                          <div class="modal-content" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
                            <div class="modal-header"><h5 class="modal-title">Assignments</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                             <div class="modal-body">
                              
                        
                              <form method="post" action="assstore">
                                {{ csrf_field() }} 
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Your name:</label>
            <input type="text" name="yname" class="form-control" id="recipient-name">
            <label for="recipient-name" class="col-form-label">Subject name:</label>
            <input type="text"  name="sname" class="form-control" id="recipient-name"> <br>
            <label for="formFileMultiple" class="form-label">Upload your assignment questions:</label>
            <input class="form-control" type="file" name="file" id="formFileMultiple" multiple> <br>    
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">Do you have somthing to add?</label>
            <input type="text" name="text" class="form-control" id="message-text" placeholder="Add your comment!!">
          </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Send</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </center>
                       </div>  
                     </div>    
                      </div>
            <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/project.jpg" class="img-fluid imges" alt="project">
                </div>
                <div class="card-body">  
                  <h3 class="card-title" style="color:#FF0000 ; font-family: cursive;">Projects</h3>
                  <p class="card-text">Will help you to build your projects.</p>
                      <center>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal3">
                         Start</button>
                         @if(Auth::user()->role <= 2)
                        <a href="{{ route('projects') }}" class="btn btn-warning">View</a>
                        @endif
                       <div class="modal" id="myModal3">
                        <div class="modal-dialog">
                          <div class="modal-content" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
                            <div class="modal-header"><h5 class="modal-title">Projects</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                             <div class="modal-body">
                              
                              <<form method="post" action="prostore">
                                {{ csrf_field() }} 
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Your name or your team name:</label>
            <input type="text" name="yname" class="form-control" id="recipient-name">
            <label for="recipient-name" class="col-form-label">Name of yor idea:</label>
            <input type="text"  name="iname" class="form-control" id="recipient-name" placeholder="write NO if you don't have!!"> <br>   
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">Abstract of your idea:</label>
            <input type="text" name="text" class="form-control" id="message-text" placeholder="write NO if you don't have!!">
          </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Send</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </center>
                        
                      </center>
                       </div>
                     </div>
                   </div>
            <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/guide.jpg" class="img-fluid imges" alt="guid">
                </div>
                <div class="card-body">  
                  <h3 class="card-title" style="color:#FF0000 ; font-family: cursive;">Guide</h3>
                  <p class="card-text">Will guide you in your technology trip.</p>
                  <center>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal2">
                         Start</button>
                         @if(Auth::user()->role <= 2)
                        <a href="{{ route('guides') }}" class="btn btn-warning">View</a>
                        @endif
                       <div class="modal" id="myModal2">
                        <div class="modal-dialog">
                          <div class="modal-content" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
                            <div class="modal-header"><h5 class="modal-title">Guide</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                             <div class="modal-body">
                              
                              <form method="post" action="guistore">
                                {{ csrf_field() }} 
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Your name or your team name:</label>
            <input type="text" name="yname" class="form-control" id="recipient-name">
            <label for="recipient-name" class="col-form-label">Name of project:</label>
            <input type="text"  name="pname" class="form-control" id="recipient-name"> <br> 
            <label for="recipient-name" class="col-form-label">Type of project:</label>
            <input type="text"  name="ptype" class="form-control" id="recipient-name"> <br>  
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">Abstract of the project & technology used :</label>
            <input type="text" name="text" class="form-control" id="message-text" placeholder="write NO if you don't have!!">
          </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Send</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </center>
                    </div>  
                  </div>    
                </div>
                <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/article.jpg" class="img-fluid imges" alt="article">
                </div>
                <div class="card-body">  
                  <h3 class="card-title" style="color:#FF0000 ; font-family: cursive;">Articles</h3>
                  <p class="card-text">See an intireisting and important articls.</p>
                      <center>
                        <a href="{{ route('articles') }}" class="btn btn-primary">start</a>
                      </center>
                       </div>
                     </div>
                   </div>
                   <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/volunteer.jpg" class="img-fluid imges" alt="volunteering">
                </div>
                <div class="card-body">  
                  <h3 class="card-title" style="color:#FF0000 ; font-family: cursive;">Volunteering</h3>
                  <p class="card-text">Welcome to our volunteer team.</p>
                      <center>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal">
                         Start</button>
                         @if(Auth::user()->role <= 2)
                        <a href="{{ route('volus') }}" class="btn btn-warning">View</a>
                        @endif
                       <div class="modal" id="myModal">
                        <div class="modal-dialog">
                          <div class="modal-content" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
                            <div class="modal-header"><h5 class="modal-title">Volunteering</h5><button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                             <div class="modal-body">
                              
                             <form method="post" action="volstore">
                                {{ csrf_field() }} 
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Name of Volunteer:</label>
            <input type="text" name="vname" class="form-control" id="recipient-name">
            <label for="recipient-name" class="col-form-label">Your ID:</label>
            <input type="text"  name="vid" class="form-control" id="recipient-name"> <br>
            <label for="formFileMultiple" class="form-label">Name of Course:</label>
            <input class="form-control" type="text" name="cname" id="formFileMultiple" multiple> <br>    
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">Abstract of course & knowledge:</label>
            <input type="text" name="text" class="form-control" id="message-text">
          </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Send</button>
                          </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </center>
                </div>
              </div>
            </div>
            <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/others.png" class="img-fluid imges" alt="others">
                </div>
                <div class="card-body">  
                  <h3 class="card-title" style="color:#FF0000 ; font-family: cursive;">Others</h3>
                  <p class="card-text">Do yo need new service? Tell us...</p>
                      <center>
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal" data-bs-whatever="@getbootstrap">Start</button>
                        @if(Auth::user()->role <= 2)
                        <a href="{{ route('others') }}" class="btn btn-warning">View</a>
                        @endif

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Others</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form method="post" action="othstore">
                                {{ csrf_field() }} 
          <div class="mb-3">
            <label for="recipient-name" class="col-form-label">Name of service:</label>
            <input type="text" name="sname" class="form-control" id="recipient-name">  
          </div>
          <div class="mb-3">
            <label for="message-text" class="col-form-label">Explain:</label>
            <input type="text" name="text" class="form-control" id="message-text">
          </div>
                            <div class="modal-footer">
                              <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary">Send</button>
                          </div>
                          </form>
    </div>
  </div>
</div>
                    </center>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
@endsection