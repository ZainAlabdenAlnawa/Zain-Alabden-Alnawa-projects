<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

     <!-- Bootstrap CSS -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">


     <!-- Styles -->
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">
    <link href="{{ asset('css/stylesignup.css') }}" rel="stylesheet">

    <title>{{ config('app.name', 'Laravel') }}</title>

    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    
</head>
<body class="body">
<nav class="navbar navbar-expand-sm" style="background-color:#3277BC;">
  <div class="container-fluid">
     <a class="navbar-brand" href="{{ route('home') }}">
      <img src="{{ asset('img/dhoom1.png') }}" alt="Logo" width="90px" height="70" ; class="rounded-pill"> 
      <span style="color:#F8F8FF"> Distance Learning </span>
      </a>
    
    <!-- Links -->
    <!-- Authentication Links -->
    <ul class="navbar-nav">
    @guest
                            @if (Route::has('login'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('login') }}" style="color:#F8F8FF">{{ __('Login') }}</a>
                                </li>
                            @endif

                            @if (Route::has('register'))
                                <li class="nav-item">
                                    <a class="nav-link" href="{{ route('register') }}" style="color:#F8F8FF">{{ __('Sign up') }}</a>
                                </li>
                            @endif
                        @else
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre style="color:#F8F8FF">
                                    {{ Auth::user()->name }}
                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="{{ route('Profile') }}">
                                    {{ __('Profile') }}
                                    </a>
                                    @if(Auth::user()->role <= 2)
                                    <a class="dropdown-item" href="{{ route('controls') }}">
                                    {{ __('control') }}
                                    </a>
                                    @endif
                                    
                                    <a class="dropdown-item" href="{{ route('logout') }}"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        {{ __('Logout') }}
                                    </a>

                                    <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                                        @csrf
                                    </form>
                                    
                                </div>
                            </li>
                        @endguest

      <li class="nav-item">
        <a class="nav-link" href="{{ route('aboutus') }}" style="color:#F8F8FF">About US</a>
      </li>
    </ul>
  </div>
</nav>

    <div >

        <main class="py-4">
            @yield('content')
        </main>
    </div>

   
        <footer class="footer" > 
               
               <center>
                   <p>Copyright &copy <a href="https://dhoomlearning.blogspot.com/" style="color:darkred;font-size: 15px;font-weight: bold;" >DHOOM</a> Group. All Rights Reserved.</p>
                   <p>This website is developed by DHOOM Team</p>
               </center>
               </footer>
            
           

    <!--Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>
