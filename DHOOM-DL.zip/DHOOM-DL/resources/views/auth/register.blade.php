@extends('layouts.app')

@section('content')

                  <!--  <center class="container1">
<div class="form-bg">
    <div class="container">
        <div class="row">
            <div class="col-md-offset-3 col-md-6 col-sm-offset-2 col-sm-8">
                <div class="form-container">
                    <h3 class="title">{{ __('User Registration') }}</h3>
                   <form class="form-horizontal" name="Register" method="POST" action="{{ route('register') }}">
                        @csrf

                        <div class="form-group">
                            <label for="name">{{ __('name') }}</label>
                                <input class="form-control @error('name') is-invalid @enderror" type="text" id="name" name="firstName" value="{{ old('name') }}"required autocomplete="name" autofocus>
                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="form-group">
                            <label for="lname">{{ __('Last Name*') }}</label>
                                <input class="form-control @error('name') is-invalid @enderror" type="text" id="lname" name="lastName" value="{{ old('name') }}"required autocomplete="first name" autofocus>
                                @error('lastname')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="form-group">
                            <label for="email">{{ __('Email ID*') }}</label>
                                <input class="form-control @error('email') is-invalid @enderror" type="email" id="lname" name="email" value="{{ old('name') }}"required autocomplete="email" >
                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror    
                            </div>
                            <div class="form-group">

                            <label for="password" >{{ __('Password*') }}</label>
                                <input id="lname" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="form-group">
                            
                            <label for="password-confirm">{{ __('Confirm Password*') }}</label>
                                <input id="lname" type="password" class="form-control" name="confirmPassword" required autocomplete="new-password">
                            </div>
                            <div class="form-group">
                                <label for="Phone No">{{ __('Phone No*') }}</label>
                                <input id="lname" type="text" class="form-control" name="Phoneno" required autocomplete="Phone-No">
                            </div>
                            <div class="form-group">

                                <label for="Country">{{ __('Country*') }}</label>
                                <input id="lname" type="text" class="form-control" name="country" required autocomplete="Country">
                                </div>    
                        <br>
                        
                        <br>
                        <button type="submit" class="registe btn" onclick="validateForm()" >{{ __('Creat Account') }}</button>
                        <br> 
                        <span class="user-login">Already Have an Account? Click Here to <a href="login.html">Login</a></span>
                    </form>
                    
                    <div class="social-links">
                        <span>Or Connect With</span>
                        <a href="#"><i class="fab fa-google"></i> google</a>
                        <a href="#"><i class="fab fa-facebook-f"></i> facebook</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</center>-->

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
                <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;">{{ __('Creat Account') }}
            </div>
            </center>

                <div class="card-body" >
                    <form method="POST" action="{{ route('register') }}">
             
                        @csrf

                        <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end">{{ __('Name') }}</label>

                            <div class="col-md-6">
                                <input id="name" type="text" class="form-control @error('name') is-invalid @enderror" name="name" value="{{ old('name') }}" required autocomplete="name" autofocus>

                                @error('name')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end">{{ __('Email Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email">

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-end">{{ __('Confirm Password') }}</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required autocomplete="new-password">
                            </div>
                        </div>

                  <div class="row mb-3">
                            <label for="phone" class="col-md-4 col-form-label text-md-end">{{ __('phone') }}</label>

                            <div class="col-md-6">
                                <input id="phone" type="text" class="form-control @error('phone') is-invalid @enderror" name="phone" required >
                                @error('phone')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror
                            </div>
                        </div>

                       <div class="row mb-3">
                            <label for="name" class="col-md-4 col-form-label text-md-end">{{ __('country') }}</label>

                            <div class="col-md-6">
                            <input id="country" type="text" class="form-control @error('country') is-invalid @enderror" name="country" required >
                                @error('country')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                                @enderror

                                
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <center>
                                <button type="submit" class="btn btn-primary" style="color: #fff; background-color: #0cd674; box-shadow: 0 0 10px rgba(0,0,0,0.3),0 0 10px rgba(0,0,0,0.3) inset;">
                                    {{ __('Creat Account') }}
                                </button>
                            </center>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection



