@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;">{{ __('Projects') }}</div>
                </center>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student or Team Name</th>
                                <th>Idea Name</th>
                                <th>Abstract</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($projects as$project)
                            <tr>
                                <td>{{ $project->yname }}</td>
                                <td>{{ $project->iname }}</td>
                                <td>{{ $project->text }}</td>
                                <td><a href="/projects/{{$project->id}}/prodelete" class="btn btn-danger">delete</a></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection