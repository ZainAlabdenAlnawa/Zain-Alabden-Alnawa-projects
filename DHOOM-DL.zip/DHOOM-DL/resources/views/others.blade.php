@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;">{{ __('Others') }}</div>
                </center>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Name of service</th>
                                <th>Explain</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($others as$other)
                            <tr>
                                <td>{{ $other->sname }}</td>
                                <td>{{ $other->text }}</td>
                                <td><a href="/others/{{$other->id}}/othdelete" class="btn btn-danger">delete</a></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection