@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-10">
        <div class="card" style="background-image: linear-gradient(to bottom right, #86F288, #F8F8FF);">
            <center>
                <div class="card-header" style="font-size: 27px; font-weight: 600; color:#FF0000 ; font-family: cursive;">{{ __('volunteers') }}</div>
                </center>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>volunteers Name</th>
                                <th>volunteers id</th>
                                <th>Course name</th>
                                <th>Abstract & technology</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        @foreach($volus as$volu)
                            <tr>
                                <td>{{ $volu->vname }}</td>
                                <td>{{ $volu->vid }}</td>
                                <td>{{ $volu->cname }}</td>
                                <td>{{ $volu->text }}</td>
                                <td><a href="/volus/{{$volu->id}}/voldelete" class="btn btn-danger">delete</a></td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
</div>

@endsection