<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\type;
use App\Models\course;
class TypeController extends Controller
{
    public function coursesstore(Request $request, type $type)
    {
        $course = new course;
        $course->path = $request->path ;
        $course->title = $request->title ;
        $course->text = $request->text ;
        $type->courses()->save($course);
        return back();
    }
}
