<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;

use DB;
use app\Models\User;
use App\Models\type;
use App\Models\course;
use App\Models\Article;
use App\Models\assignment;
use App\Models\project;
use App\Models\guide;
use App\Models\volu;
use App\Models\other;


class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('home');
    }
    public function Profile()
    {
        return view('Profile');
    }
    public function control()
    {
        if(Auth::user()->role == 4 || Auth::user()->role == 3)
        {
            return redirect('/home');
        }
        $users = DB::table('users')->get();
        return view('control', compact('users'));
    }

    public function onetype(type $type)
    {
        return view('onetype', compact('type'));
    }

    public function controls()
    {
        if(Auth::user()->role == 4 || Auth::user()->role == 3)
        {
            return redirect('/home');
        }
        return view('controls');
    }


    public function updaterole(Request $request, User $user)
    {
        $user->update($request->all());
        return redirect('control');
    }
    public function aboutus()
    {
        return view('aboutus');
    }
    public function types()
    {
        $types = DB::table('types')->get();
        return view('types', compact('types'));
    }

    public function typesstore(Request $request)
    {
        $type = new type;
        $type->path = $request->path ;
        $type->title = $request->title ;
        $type->text = $request->text ;
        $type->save();
        return back();
    }
    public function typesdelete(type $type)
    {
        $type->delete();
        return back();
    }
    
    public function courses()
    {
        return view('courses');
    }
    public function services()
    {
        return view('services');
    }
    public function articels()
    {
        return view('articels');
    }
    public function articles()
    {
        $articles = DB::table('articles')->get();
        return view('articles', compact('articles'));
    }
    public function artsstore(Request $request)
    {
        $Article = new Article;
        $Article->path = $request->path ;
        $Article->title = $request->title ;
        $Article->provider = $request->provider ;
        $Article->text = $request->text ;
        $Article->save();
        return back();
    }
    public function articlesdelete(Article $Article)
    {
        $Article->delete();
        return back();
    }
    public function articlesedit(Article $Article)
    {
        
        return view('aedit', compact('Article'));
    }
    public function articlesupdate(Request $request , Article $Article)
    {
        $Article->update($request->all());
        return redirect('articles/' );
    }
    public function assignments()
    {
        if(Auth::user()->role == 4 || Auth::user()->role == 3)
        {
            return redirect('/home');
        }
        $assignments = DB::table('assignments')->get();
        return view('assignments', compact('assignments'));
    }
    public function assstore(Request $request)
    {
        $assignment = new assignment;
        $assignment->yname = $request->yname ;
        $assignment->sname = $request->sname ;
        $assignment->file = $request->file ;
        $assignment->text = $request->text ;
        $assignment->save();
        return back();
    }
    public function assdelete(assignment $assignment)
    {
        $assignment->delete();
        return back();
    }
    public function projects()
    {
        if(Auth::user()->role == 4 || Auth::user()->role == 3)
        {
            return redirect('/home');
        }
        $projects = DB::table('projects')->get();
        return view('projects', compact('projects'));
    }
    public function prostore(Request $request)
    {
        $project = new project;
        $project->yname = $request->yname ;
        $project->iname = $request->iname ;
        $project->text = $request->text ;
        $project->save();
        return back();
    }
    public function prodelete(project $project)
    {
        $project->delete();
        return back();
    }
    public function guides()
    {
        if(Auth::user()->role == 4 || Auth::user()->role == 3)
        {
            return redirect('/home');
        }
        $guides = DB::table('guides')->get();
        return view('guides', compact('guides'));
    }
    public function guistore(Request $request)
    {
        $guide = new guide;
        $guide->yname = $request->yname ;
        $guide->pname = $request->pname ;
        $guide->ptype = $request->ptype ;
        $guide->text = $request->text ;
        $guide->save();
        return back();
    }
    public function guidelete(guide $guide)
    {
        $guide->delete();
        return back();
    }
    public function volus()
    {
        if(Auth::user()->role == 4 || Auth::user()->role == 3)
        {
            return redirect('/home');
        }
        $volus = DB::table('volus')->get();
        return view('volus', compact('volus'));
    }
    public function volstore(Request $request)
    {
        $volu = new volu;
        $volu->vname = $request->vname ;
        $volu->vid = $request->vid ;
        $volu->cname = $request->cname ;
        $volu->text = $request->text ;
        $volu->save();
        return back();
    }
    public function voldelete(volu $volu)
    {
        $volu->delete();
        return back();
    }
    public function others()
    {
        if(Auth::user()->role == 4 || Auth::user()->role == 3)
        {
            return redirect('/home');
        }
        $others = DB::table('others')->get();
        return view('others', compact('others'));
    }
    public function othstore(Request $request)
    {
        $other = new other;
        $other->sname = $request->sname ;
        $other->text = $request->text ;
        $other->save();
        return back();
    }
    public function othdelete(other $other)
    {
        $other->delete();
        return back();
    }
    public function coursesstore(Request $request , type $type)
    {
        $course = new course;
        $course->path = $request->path ;
        $course->title = $request->title ;
        $course->text = $request->text ;
        $type->courses()->save($course);
        return back();
    }
    public function cedit(course $course)
    {
        return view('cedit', compact('course'));
    }
    public function cupdate(Request $request , course $course)
    {
        $course->update($request->all());
        return redirect('types/' . $course->type_id );
    }

}
