<!DOCTYPE html>
<html>
 <head>
    <link rel="stylesheet" type="text/css" href="index.css">
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Otomanopee+One&display=swap" rel="stylesheet">
    <!--Latest compiled and minified JavaScript--> 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>L-Product Page</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg  navbar-dark bg-primary">
      <div class="container-fluid">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav justify-content-end">
           <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index-page.php">MaRwAdI</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">LOGOUT</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="about.php">ABOUT</a>
        </li>  
          </ul>
          <form class="d-flex ser">
            <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success" style="background: black;" type="submit">Search</button>
          </form>
        </div>
      </div>
    </nav>
    <!-- Content -->
     <section class="bg-light py-4 my-5">
            <center>
                  <h2 style="color:#FF0000">Enroll Now...!</h2>
                </center>
           <div class="col-md-
      <div class="container shadow mt-5 border">
        <div class="row">
           <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/i1.jpg" class="img-fluid imges"  alt="responsive img">
                </div>
                <div class="card-body">  
                  <h3 class="card-title">IT</h3>
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Details 
                  </button>
                  <!-- Modal -->
                  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Details..</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          NAME : INFORMATION TECHNOLOGY <br> YEARS : 4  <br> SEMESTERS : 8 <br> SUBJECTS : 51 <br> Fucalty : 25 <br> Price per sem : RS.140000.00
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>

                  <a href="#" class="btn btn-danger">Enroll now</a>
               </div>  
              </div>    
          </div>
          <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/i2.jpg" class="img-fluid imges" alt="responsive img">
                </div>
                <div class="card-body">  
                  <h3 class="card-title">LAW</h3>
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Details 
                  </button>
                  <!-- Modal -->
                  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Details..</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          NAME : LAW <br> YEARS : 5  <br> SEMESTERS : 10 <br> SUBJECTS : 60 <br> Fucalty : 18 <br> Price per sem : RS.120000.00
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <a href="#" class="btn btn-danger">Enroll now</a>
               </div>  
              </div>    
          </div>
          <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/i3.jpg" class="img-fluid imges" alt="responsive img">
                </div>
                <div class="card-body">  
                  <h3 class="card-title">PHARM</h3>
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Details 
                  </button>
                  <!-- Modal -->
                  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Details..</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          NAME : PHARM <br> YEARS : 4  <br> SEMESTERS : 8 <br> SUBJECTS : 40 <br> Fucalty : 11 <br> Price per sem : RS.170000.00
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <a href="#" class="btn btn-danger">Enroll now</a>
               </div>  
              </div>    
          </div>
          <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/i4.jpg" class="img-fluid imges" alt="responsive img">
                </div>
                <div class="card-body">  
                  <h3 class="card-title">CE</h3>
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Details 
                  </button>
                  <!-- Modal -->
                  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Details..</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          NAME : COMPUTER ENGINEERING <br> YEARS : 4  <br> SEMESTERS : 8 <br> SUBJECTS : 51 <br> Fucalty : 25 <br> Price per sem : RS.140000.00
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <a href="#" class="btn btn-danger">Enroll now</a>
               </div>  
              </div>    
          </div>
          <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/i5.jpg" class="img-fluid imges" alt="responsive img">
                </div>
                <div class="card-body">  
                  <h3 class="card-title">MANAGEMENT</h3>
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Details 
                  </button>
                  <!-- Modal -->
                  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Details..</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          NAME : Business Administration <br> YEARS : 3  <br> SEMESTERS : 6 <br> SUBJECTS : 30 <br> Fucalty : 15 <br> Price per sem : RS.110000.00
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <a href="#" class="btn btn-danger">Enroll now</a>
               </div>  
              </div>    
          </div>
          <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/i6.jpg" class="img-fluid imges" alt="responsive img">
                </div>
                <div class="card-body">  
                  <h3 class="card-title">ELECATRICAL</h3>
                  <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
                    Details 
                  </button>
                  <!-- Modal -->
                  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Details..</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          NAME : ELECATRICAL <br> YEARS : 4  <br> SEMESTERS : 8 <br> SUBJECTS : 51 <br> Fucalty : 251 <br> Price per sem : RS.140000.00 .
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <a href="#" class="btn btn-danger">Enroll now</a>
               </div>  
              </div>    
          </div>
        </div>
      </div> 
    </section>  
      </div> 
    </section>  
           <!-- Footer -->
     <footer class="footer"> 
               <div class="container">
               <center>
                   <p>Copyright &copy <a href="https://marwadiuniversity.ac.in/" style="color:red">MARWADI</a> University. All Rights Reserved.</p>
                   <p>This website is developed by Zain Alabden Alnawa</p><p>This website is sponsored by the <h6 style="color:darkorange;">Guide Dr.Krunal Vaghela</h6></p>
               </center>
               </div>
           </footer>
  </body>
</html>
