<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="index.css">
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v5.15.3/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Otomanopee+One&display=swap" rel="stylesheet">
    <!--Latest compiled and minified JavaScript--> 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Product Page</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg  navbar-dark bg-primary">
  <div class="container-fluid">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav justify-content-end">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#">MU Distance-education</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="Signup-Page.php">SIGN-UP</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="LoginPage.php">LOGIN</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="about.php">ABOUT</a>
        </li>  
      </ul>
    </div>
  </div>
</nav>
    <section class="bg-light py-4 my-5">
      <div class="container shadow mt-5 border">
        <div class="row">
          <div class="container shadow mt-5 border">
        <div class="row">
          <div class="alert alert-danger">
            <strong>Info!</strong>  Need to login to see the details and enroll..!!
           </div>
           <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/i1.jpg" onclick="alert('Need to login to see the details and shop..!!')" class="img-fluid" alt="IT">
                </div>
                <center>
                <div class="card-body">  
                  <h4 class="card-title">IT</h4>
                </div> 
                </center> 
              </div>    
          </div>
          <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/i2.jpg" onclick="alert('Need to login to see the details and shop..!!')" class="img-fluid" alt="LAW">
                </div>
                 <center>
                <div class="card-body">  
                  <h4 class="card-title">LAW</h4>
                </div>
                 </center>  
              </div>    
          </div>
          <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/i3.jpg" onclick="alert('Need to login to see the details and shop..!!')" class="img-fluid" alt="PHARM">
                </div>
                <center>
                <div class="card-body">  
                  <h4 class="card-title">PHARM</h4>
                </div>
                 </center> 
              </div>    
          </div> 

         <div class="container shadow mt-5 border">
        <div class="row">
          <div class="alert alert-danger">
            <strong>Info!</strong>  Need to login to see the details and enroll..!!
           </div>
           <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/i4.jpg" onclick="alert('Need to login to see the details and shop..!!')" class="img-fluid" alt="CE">
                </div>
                <center>
                <div class="card-body">  
                  <h4 class="card-title">CE</h4>
                </div> 
                </center> 
              </div>    
          </div>

          <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/i5.jpg" onclick="alert('Need to login to see the details and shop..!!')" class="img-fluid" alt="MANAGEMENT">
                </div>
                 <center>
                <div class="card-body">  
                  <h4 class="card-title">MANAGEMENT</h4>
                </div>
                 </center>  
              </div>    
          </div>
          <div class="col-md-6 col-lg-4">
              <div class="card my-3">
                <div class="card-thumbnail">
                  <img src="img/i6.jpg" onclick="alert('Need to login to see the details and shop..!!')" class="img-fluid" alt="ELECATRICAL">
                </div>
                <center>
                <div class="card-body">  
                  <h4 class="card-title">ELECATRICAL</h4>
                </div>
                 </center> 
              </div>    
          </div> 
           <div class="alert alert-danger">
            <strong>Info!</strong>  Need to login to see the details and enroll..!!
           </div>
        </div>
      </div> 
    </section>
   <footer class="footer"> 
               <div class="container">
               <center>
                   <p>Copyright &copy <a href="https://marwadiuniversity.ac.in/" style="color:red">MARWADI</a> University. All Rights Reserved.</p>
                   <p>This website is developed by Zain Alabden Alnawa</p><p>This website is sponsored by the <h6 style="color:darkorange;">Guide Dr.Krunal Vaghela</h6></p>
               </center>
               </div>
           </footer>
  </body>
</html>
