<!DOCTYPE html >
<html>
<head>
	<title>Contact</title>
	<link rel="stylesheet" type="text/css" href="css/contact.css">
</head>
	<body>
		<ul>
			<li><a href="Home.php"><strong>| Home</strong></a> </li>
			<li><a href="login.php"><strong>| login</strong></a></li>
			<li><a href="Medical.staff.php"><strong>| Medical staff</strong></a></li>
			<li><a href="Patient.php"><strong>| Patient platform</strong></a></li>
			<li><a href="https://nunm.edu/"><strong>| Natural Medicine</strong></a></li>
			<li><a href="contact.php"><strong>| Contact Us</strong></a> </li>
			<li><a href="About.php"><strong>| About</strong></a></li>
		
		</ul>
		<TABLE border=5>
		<tr>
			<td><img src="images/contact.jpg" class="image" alt="pic">
			<br><h1>ALSAQER_Hospital</h1></td>
		</tr>
		</TABLE>

		
			<div id="container">
			
				<table border=20 class="stable">
					<thead>
						<tr>
							<th></th>
							<th class="iron"><img src="images/photo.jpg" alt="photo pic" width="200px;" /></th>
							<th class="he"><strong><h1> The main phone numbers in the hospital</h1></strong></th>
							
						</tr>
						
					</thead>
					
					<tbody>
						<tr>
							<td class="feature">External hospital divider :</td>
							<td class="iron">****/****</td>
							<td class="nightster">Inpatient hospital divider :</td>
							<td class="fortyeight">****/****</td>
						</tr>
						
						<tr>
							<td class="feature">Emergency :</td>
							<td class="iron">****/****</td>
							<td class="nightster">Hospital inquiries :</td>
							<td class="fortyeight">****/****</td>
						</tr>
						
						<tr>
							<td class="feature">Appointments :</td>
							<td class="iron">****/****</td>
							<td class="nightster">Nursing Department :</td>
							<td class="fortyeight">****/****</td>
						</tr>
						
						<tr>
							<td class="feature">Nutrition services :</td>
							<td class="iron">****/****</td>
							<td class="nightster">Hospital security :</td>
							<td class="fortyeight">****/****</td>
						</tr>
						
						<tr>
							<td class="feature">Rays :</td>
							<td class="iron">****/****</td>
							<td class="nightster">blood bank :</td>
							<td class="fortyeight">****/****</td>
						</tr>
						
						<tr>
							<td class="feature">Orthopedic Clinic :</td>
							<td class="iron">****/****</td>
							<td class="nightster">Urology Clinic :</td>
							<td class="fortyeight">****/****</td>
						</tr>

					</tbody>
				
				</table>
				

			</div>

	


	</body>
</html>