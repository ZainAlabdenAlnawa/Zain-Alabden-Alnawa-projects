<?php

$con = mysqli_connect("localhost", "root", "", "hospitalsys") or die(mysqli_error($con));
session_start();
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];
$contact = $_POST['contact'];
$city = $_POST['city'];
$address = $_POST['address'];
$user_signup_query = "insert into signup(username, email, password, contact, city, address) values ('$username', '$email', '$password', '$contact', '$city', '$address')";
$user_signup_submit = mysqli_query($con, $user_signup_query) or die(mysqli_error($con));
echo "User successfully inserted";
$_SESSION['username'] = $username;
$_SESSION['id'] = mysqli_insert_id($con);
?>