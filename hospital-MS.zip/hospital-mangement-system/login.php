<!DOCTYPE html>
<html>
    <head>
        <title>User login form</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            .top_margin{
                margin-top:20px;
            }
        </style>
    </head>
</head>
    <body>



                        <?php
                        if (isset($_SESSION['email'])) {
                        ?>

                        <?php
                        } else {
                        ?>

                        <?php
                        }
                        ?>
                    


        <div class="container">
            <div class="row top_margin">
                <div class="col-xs-6 col-xs-offset-3">
                    <div class="panel panel-primary">
                        <div class="panel-heading">Login</div>
                        <div class="panel-body">
                            <form method="POST" action="user_login_script.php">
                                <div class="form-group">
                                    <label for="username">User Name</label>
                                    <input type="username" class="form-control" id="username" name="username">
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input type="password" class="form-control" id="password" name="password">
                                </div>
                            
                                <button type="submit" class="btn btn-primary" value="login_submit">Submit</button><br>
                                <a href="forget pass.php">Forget your password?</a><br>
                                <a href="signup.php">Don't have account?</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div><br><br><br><br><br><br><br><br><br><br><br><br>

        <div class="foter" >
			<center>
				<p>Copyright &copy; Lifestyle Store. All Rights Reserved | Contact Us: +91 9000000000.</p> 
			</center>	
			
		</div>
    </body>
</html>