<!DOCTYPE html>
<html>
<head>
	<title>Patient</title>
	<link rel="stylesheet" type="text/css" href="css/patient.css">
</head>
<body>
	 <ul>
      <li><a href="Home.php"><strong>| Home</strong></a> </li>
      <li><a href="Medical.staff.php"><strong>| Medical staff</strong></a></li>
      <li><a href="Patient.php"><strong>| Patient platform</strong></a></li>
      <li><a href="https://nunm.edu"><strong>| Natural Medicine</strong></a></li>
      <li><a href="contact.php"><strong>| Contact Us</strong></a> </li>
      <li><a href="About.php"><strong>| About</strong></a></li>
      
    </ul>
	
		<div class="header">
			<h1><strong>!</strong> COVID-19 is an emerging, rapidly evolving situation.</h1>
			<img src="images/pa9.jpg" class="pa">
		</div><br><br><br><br>
	<div class="all">	
		<div class="para">
			<br><br><br><h2>GP RECOMMENDATIONS FOR PATIENTS :</h2><br><br>
			<p>As doctors we are constantly striving to improve our consultation skills, to get the most out of our precious 10 minutes with our patient. But who is providing our patients with feedback on their consultation style? Can we support our clients to be better patients?

			In a survey in January 2018 using social media, I asked (on behalf of my blog teachmegp.com) a group of 5956 GPs and GP trainees:<br>

	    	‘What advice would you give your patients about improving their GP appointment?’<br>

			The answers were in the form of free text. <br>We discovered 34 different recommendations for patients about their 10-minute consultation. <br>This article reports only suggestions that were made by at least two independent doctors. <br>
			Recommendations from GPs could be divided into two overarching themes: </p>
			<ul>
				<li>patient preparation before their consultation; and</li>
				<li>behaviour and attitude during the consultation.</li>
			</ul>
			<img src="images/pat.jpg" class="image" alt="avatar">

		</div>
		<div class="spara">
			<h2>PREPARING PATIENTS BEFORE THEIR CONSULTATION :</h2><br><br>
			<p>
				GPs commonly discussed issues surrounding booking with the correct professional, turning up ahead of time, and arranging continuity of care with the same professional where feasible.<br>

				Bringing a friend or booking a translator if there were issues surrounding communicating in English were recommended. Advice on prioritising their concerns, preparing lists of symptoms or questions for the doctor, and having realistic expectations of what could be achieved within 10 minutes were points very well cited.<br>

				Examination tips included dressing appropriately for the problem at hand and the likely examination. In the winter months it was suggested that patients consider removing outer layers of clothing prior to stepping into the consultation room. Good patient hygiene and cleanliness was recommended as a matter of courtesy, especially in the context of likely intimate examinations.<br>
			</p>
			<img src="images/pat1.jpg">
		</div>
		<div>
			<h2>BEHAVIOUR AND ATTITUDE DURING THE CONSULTATION :</h2><br><br>
			<p>
				Patients were asked to avoid taking offence should a follow-up appointment be recommended to address additional health concerns. They were asked to be more specific about details of their history, such as the timing of symptom onset. Remaining topic-focused and avoiding tangential descriptions was suggested as a good way of improving efficiency in the consultation.<br>

Patients were encouraged to consider potential disease transference from them to the doctor, and to be mindful and appreciative of this throughout the consultation.<br>

Children should be encouraged to cover their mouths when coughing and parents were asked to monitor their children’s behaviour closely during the consultation. Doctors wanted mobile phones to be put on silent and not answered, within reason. Other clear distractors, such as children being given food, were also mentioned.<br>

An emphasis was placed on patients being open and honest with their doctor, to expect lots of questions, often personal, and to be understanding of the fact that GPs are not always fully informed on their full past medical history.<br>

It was noted that patients should expect to have their opinion on the problem explored further and to avoid taking offence around this issue where possible. Shared decision making is now the cornerstone of treatment, and this would be best explained to patients in advance.<br>
			</p>
			<img src="images/pat2.jpg">
		</div>
	</div><br><br>

	<div class="foter" >
			<center>
				<p>Copyright &copy; Lifestyle Store. All Rights Reserved | Contact Us: +91 9000000000.</p> 
			</center>	
			
	</div>
</body>
</html>