<?php

$con = mysqli_connect("localhost", "root", "", "hospitalsys") or die(mysqli_error($con));
session_start();
$username = $_POST['username'];
$password = $_POST['password'];
$user_login_query = "insert into login(username, password) values ('$username', '$password')";
$user_login_submit = mysqli_query($con, $user_login_query) or die(mysqli_error($con));
echo "User successfully inserted";
$_SESSION['username'] = $username;
$_SESSION['id'] = mysqli_insert_id($con);
?>