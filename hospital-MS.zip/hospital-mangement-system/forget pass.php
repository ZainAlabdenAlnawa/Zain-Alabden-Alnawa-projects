<!DOCTYPE html>
<html>
<head>
	<title>foret pass</title>
	<link rel="stylesheet" type="text/css" href="css/forget pass.css">
</head>
<body>
	<div class="login">
      <img src="images/patent.jpg" class="avatar">
      <h1>Enter your Email & New Pass</h1>
      <form>
        <p>Username</p>
        <input type="username" name="" placeholder="Enter username">
        <P>New password</P>
        <input type="password" name="" placeholder="Enter password">
        
        <P>Confirm New password</P>
        <input type="password" name="" placeholder="Enter password">
        <a href="patient.php">
        <input type="button" value="login" />
        </a>
      </form>

  </div>

</body>
</html>