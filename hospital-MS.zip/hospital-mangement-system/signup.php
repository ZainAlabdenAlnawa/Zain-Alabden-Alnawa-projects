<!DOCTYPE html>
<html>
    <head>
        <title>User login form</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" >
        <!--jQuery library--> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <!--Latest compiled and minified JavaScript--> 
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            .top_margin{
                margin-top:20px;
            }
        </style>
    </head>
</head>
    <body>



        <div class="container">
            <div class="row top_margin">
                <div class="col-xs-6 col-xs-offset-3">
                    <div class="panel panel-primary">
                        <div class="panel-heading">Login</div>
                        <div class="panel-body">
                            <form method="POST" action="user_signup_script.php">
                                

                                <div class="form-group">
                                    <label for="username">Name</label>
                                    <input type="username" class="form-control" id="username" name="username">
                                </div>

                                <div class="form-group">
                                    <label for="email">Email-ID</label> 
                                    <input type="email" class="form-control" id="email" name="email">
                                    </div>

                                <div class="form-group"> 
                                    <label for="password">Password</label>
                                    <input type="password" class="form-control" id="password" name="password">
                                </div>

                                <div class="form-group"> 
                                    <label for="contact">Contact</label>
                                    <input type="contact" class="form-control" id="contact" name="contact">
                                </div>

                                <div class="form-group"> 
                                    <label for="city">City</label>
                                    <input type="city" class="form-control" id="city" name="city">
                                </div>

                                <div class="form-group">
                                    <label for="address">Address</label> 
                                    <input type="address" class="form-control" id="address" name="address">
                                </div>
                            
                                <button type="submit" class="btn btn-primary" value="signup_submit">Submit</button><br>
                                
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div><br><br><br><br><br><br><br><br><br><br><br><br>

        <div class="foter" >
			<center>
				<p>Copyright &copy; Lifestyle Store. All Rights Reserved | Contact Us: +91 9000000000.</p> 
			</center>	
			
		</div>
    </body>
</html>