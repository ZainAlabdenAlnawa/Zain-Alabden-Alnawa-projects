
<!DOCTYPE html>
<html lang="fr">
<head>
	<title>Home page</title>
	<link rel="stylesheet" type="text/css" href="css/Home.css">
</head>
<body>

  <TABLE border=5 >
    <tr>
      <td><img src="images/hos.jpg" class="image" alt="pic">
        <br><h1>ALSAQER_Hospital</h1></td>
    </tr>


  </TABLE>

	 <ul>
      <li><a href="Home.php"><strong>| Home</strong></a> </li>
      <li><a href="login.php"><strong>| login</strong></a></li>
      <li><a href="Medical.staff.php"><strong>| Medical staff</strong></a></li>
      <li><a href="Patient.html"><strong>| Patient platform</strong></a></li>
      <li><a href="https://nunm.edu/"><strong>| Natural Medicine</strong></a></li>
      <li><a href="contact.php"><strong>| Contact Us</strong></a> </li>
      <li><a href="About.php"><strong>| About</strong></a></li>
      
    </ul>
    	

	  
	  <div class="list">
    	<br><br><br><br><h2>1-Traditional food systems : </h2> <h4>Overexposure to the sun during peak summer hours especially between 11 am and 4 pm may lead to extreme loss of fluid and electrolytes and may even make the person unconscious. Children, seniors, athletes and outdoor workers are at a greater risk. Hydrate the person and ask them to take a cold water shower for immediate relief.</h4>
    	<a href="hot.php" target="_blank"><img src="images/hot.jpg" class="hot" alt="pic"></a><br>
    </div>
    <div class="hn">
    	<h2 >2-Endometriosis :</h2>
    	<h3>Endometriosis has no cure! There are medical treatments that suppress symptoms (sometimes). There are surgical treatments that remove the disease. But there is no way to prevent the recurrence of the disease</h3><br><br>
    	<a href="e.php" target="_blank"><img src="images/e.jpg" class="e" alt="pic"></a>
    </div>
        <div class="hea">
          <h2>Open heart surgery can be avoided :</h2>
          <h3>Results of experiments that announce their results on Sunday showed that replacement heart valves by Medtronic and its competitor Edwards Life Science are comparable to or better than open-heart surgery for younger patients, for whom the surgical intervention is less risky.</h3><br><br>
          <img src="images/pa6.jpg" class="hear" alt="pic">
        </div>

            <div class="les">
              <ul>
                <li><a href="heart.php" target="_blank"><img src="images/heart.jpg" alt="pic"></li></a>
                <li><a href="https://www.apollohospitals.com/departments/cancer" target="_blank"><img src="images/cancer.jpg" alt="pic"></a></li>
                <li><a href="https://www.apollohospitals.com/departments/neurology-neurosurgery" target="_blank"><img src="images/neurosciences.jpg" alt="pic"></a></li>
                <li><a href="https://www.apollohospitals.com/departments/personalised-health-check/what-is-aphc" target="_blank"><img src="images/medicine.jpg" alt="pic"></a></li>
                <li><a href="https://www.apollohospitals.com/departments/spine" target="_blank"><img src="images/spine.jpg" alt="pic"></a></li>
                <li><a href="https://www.apollohospitals.com/departments/emergency-trauma-care-services" target="_blank"><img src="images/emergency.jpg" alt="pic"></a></li>
              </ul> 
            </div>
            


  
</body>
</html>