<!DOCTYPE html>
<html>
<head>
	<title>Traditional food systems </title>
	<link rel="stylesheet" type="text/css" href="css/hot.css">
</head>
<body>
	<div class="header">
		<h1>----Health----</h1>
		<ul>
      <li><a href="Home.php"><strong>| Home</strong></a> </li>
      <li><a href="login.php"><strong>| login</strong></a></li>
      <li><a href="Medical.staff.php"><strong>| Medical staff</strong></a></li>
      <li><a href="Patient.php"><strong>| Patient platform</strong></a></li>
      <li><a href="https://nunm.edu"><strong>| Natural medicine</strong></a></li>
      <li><a href="contact.php"><strong>| Contact Us</strong></a> </li>
      <li><a href="About.php"><strong>| About</strong></a></li>
      
    </ul>	
	</div>
	<div>
		<img src="images/food1.jpg" class="food1">
		<img src="images/food4.jpg" class="food4">
		<img src="images/food.jpg" class="food">
		<h1>Traditional food systems :</h1><br>
		<p><strong> 1. Traditional Food Systems of Indigenous Peoples Barbara Burlingame, PhD FAO
		<br><br>2. Definitions Indigenous peoples (PFII, 2007) • Self- identification • Historical continuity with pre-colonial and/or pre-settler societies • Strong link to territories and surrounding natural resources • Distinct language, culture and beliefs • Resolve to maintain and reproduce their ancestral environments and systems as distinctive peoples and communities Traditional food systems • Local access • Ecosystem service • Product of traditional knowledge and the natural environment • Naturally resilient, adapted food plants and animals
		<br><br>3. Issues • Diets are not sustainable – 870 million hungry people – 2 billion people with micronutrient malnutrition – 2 billion people overweight and obese • Environments are not sustainable – ecosystems degraded – biodiversity forever lost • Food systems are not sustainable – Deforestation, intensive livestock industries, imports of “popularly positioned products”, agricultural and industrial chemical contaminations
		<br><br>4. Distribution of hunger in the world
		<br><br>5. •27.6 •23.7 •18.1 •10 •13.5 •200 •150 •38.2 •190 •138 •100 •30 •39.3 •37.7 •100 •60 •50 •40.3 •Number of stunted (millions) •48.6 •2 0 •Stunting (%) •40 •50 Stunting prevalence and number affected in developing countries •51 •45 •10 •7 •0 •0 •13 •1990 •2000 •2010 •Source: Department of Nutrition, World Health Organization •AFRICA •CFS •Roma, 14th October 2010 •1990 •ASIA •2000 •2010 •LATIN AMERICA
		<br><br>>6. •6 •5.7 •4.9 •4 •4 •20 •14 •13 •13 •7 •4 •4 •4 •4 •0 •2 •3.2 •3.7 •15 •6.9 •10 •6.8 •18 •5 •6.8 •0 •Overweight (%) •8 •8.5 •Number of overweight (millions) •10 Overweight prevalence and number affected in developing countries •1990 •2000 •2010 •AFRICA •1990 •ASIA •2000 •2010 •LATIN AMERICA •Source: Department of Nutrition, World Health Organization
		<br><br>6. •6 •5.7 •4.9 •4 •4 •20 •14 •13 •13 •7 •4 •4 •4 •4 •0 •2 •3.2 •3.7 •15 •6.9 •10 •6.8 •18 •5 •6.8 •0 •Overweight (%) •8 •8.5 •Number of overweight (millions) •10 Overweight prevalence and number affected in developing countries •1990 •2000 •2010 •AFRICA •1990 •ASIA •2000 •2010 •LATIN AMERICA •Source: Department of Nutrition, World Health Organization
		<br><br>7. Definition of Sustainable Diets Sustainable Diets are those diets with low environmental impacts which contribute to food and nutrition security and to healthy life for present and future generations. Sustainable diets are protective and respectful of biodiversity and ecosystems, culturally acceptable, accessible, economically fair and affordable; nutritionally adequate, safe and healthy; while optimizing natural and human resources. Source: FAO, 2010
		<br><br>8. Ingano
		<br><br>9. Ingano forest resources “Let’s return to our food, our life and our tradition. With our food, we will improve our health, will recover our culture, and will take care of the natural world. We need our plants and our jungle in order to have strength and to live better.” Eva Yela, Ingano community member
		<br><br>10. Ingano forest resources “Let’s return to our food, our life and our tradition. With our food, we will improve our health, will recover our culture, and will take care of the natural world. We need our plants and our jungle in order to have strength and to live better.” Eva Yela, Ingano community member </strong></p>
	</div>

	<div class="foter" >
			<center>
				<p>Copyright &copy; Lifestyle Store. All Rights Reserved | Contact Us: +91 9000000000.</p> 
			</center>	
			
	</div>
	
</body>
</html>