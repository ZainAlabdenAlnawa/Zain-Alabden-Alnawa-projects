<!DOCTYPE html>
<html>
<head>
	<title>About</title>
	<link rel="stylesheet" type="text/css" href="css/About.css">
</head>
<body>
	<div class="all">
		<div class="list">
			<img src="images/h2.jpg" class="photo2">
			<ul>
				<li><a href="Home.php"><strong>| Home</strong></a> </li>
	    	    <li><a href="login.php"><strong>| login</strong></a></li>
	    	    <li><a href="Medical.staff.php"><strong>| Medical staff</strong></a></li>
	            <li><a href="Patient.php"><strong>| Patient platform</strong></a></li>
	            <li><a href="https://nunm.edu"><strong>| Natural Medicine</strong></a></li>
	            <li><a href="contact.php"><strong>| Contact Us</strong></a> </li>
	            <li><a href="About.php"><strong>| About</strong></a></li>
	            
			</ul><br><br>
			<img src="images/image.jpg" class="photo">

		</div>
		<div class="para">
			<br><br><h2>About Us:</h2>
			<p class="pa">
				A multi–specialty hospital in Thiruvananthapuram, The India Hospital has the best expertise and infrastructure for Nephrology and gets referral patients from almost all the leading hospitals in the region, both government and private sector. The full fledged hospital has all the facilities for other areas as well. An internationally trained team, best and latest equipments and homely atmosphere makes the services of The India Hospital unique.<br><br>
				Originally started as an NRI venture by a team from USA, The India Hospital maintains highest international standards in health care. The 100 bedded hospital, with A/c and non-A/c rooms and state of the art ICU keeps the cost of treatment at reasonable levels. It has subsidized treatment for the economically disadvantaged and conducts periodic free medical camps. We also have working arrangements with the traditional herbal healers of Kerala and facilitate authentic Ayurvedic treatment under modern life support cover for those interested.<br><br> 
				Dr. *****, ** (**. **.),** (***)<br>
				Chief Nephrologists is available from 8.AM to 7.PM<br>
				For Appointment contact: +91-***-*******<br><br>
				Dr. *****, ****, *** (**)<br>
				Chief Consultant Urology is available from 8.AM to 5.PM on all working days.<br>
				For Appointment contact: +91-*** ****** 
			</p>
		</div>
		
	</div><br><br>
	<div class="foter" >
		<center>
			<p>Copyright &copy; Lifestyle Store. All Rights Reserved | Contact Us: +91 9000000000.</p> 
		</center>	
		
	</div>
</body>
</html>




