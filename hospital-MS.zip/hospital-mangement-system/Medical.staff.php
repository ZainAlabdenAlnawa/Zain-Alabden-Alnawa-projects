<!DOCTYPE html>
<html>
<head>
	<title>Medical Staff</title>.css
	<link rel="stylesheet" type="text/css" href="css/Medical.staff.css">
</head>
<body>
	<TABLE border=5 >
    <tr>
      <td><img src="images/h.jpg" class="image" alt="pic">
        <br><h1>Medical_Hospital_Staff</h1></td>
    </tr>


  </TABLE>

	 <ul>
      <li><a href="Home.php"><strong>| Home</strong></a> </li>
      <li><a href="login.php"><strong>| login</strong></a></li>
      <li><a href="Medical.staff.php"><strong>| Medical staff</strong></a></li>
      <li><a href="Patient.php"><strong>| Patient platform</strong></a></li>
      <li><a href="https://nunm.edu/"><strong>| Natural Medicine</strong></a></li>
      <li><a href="contact.php"><strong>| Contact Us</strong></a> </li>
      <li><a href="About.php"><strong>| About</strong></a></li>
    </ul>
        <div>
          <table class="tap">
            <td>
              <img src="images/avatarm.jpg">
              <h4>Dr.*****</h4>
              <p><strong>Position :<br>
                Number :<br>
                email : <br>
                ABOUT :</strong> 

              </p>
            </td>
            <td>
              <img src="images/avatarm.jpg">
              <h4>Dr.*****</h4>
              <p><strong>Position :<br>
                Number :<br>
                email : <br>
                ABOUT :</strong>
            </td>
            <td>
              <img src="images/avatarm.jpg">
              <h4>Dr.*****</h4>
              <p><strong>Position :<br>
                Number :<br>
                email : <br>
                ABOUT :</strong>
            </td>
            <td>
              <img src="images/avatarw.jpg">
              <h4>Dr.*****</h4>
              <p><strong>Position :<br>
                Number :<br>
                email : <br>
                ABOUT :</strong>
            </td>
            <td>
              <img src="images/avatarw.jpg">
              <h4>Dr.*****</h4>
              <p><strong>Position :<br>
                Number :<br>
                email : <br>
                ABOUT :</strong>
            </td>
          </table>
          
        </div><br><br>
    <div class="foter" >
			<center>
				<p>Copyright &copy; Lifestyle Store. All Rights Reserved | Contact Us: +91 9000000000.</p> 
			</center>	
			
		</div>

</body>
</html>