<!DOCTYPE html>
<html>
<head>
	<title>Endometriosis</title>
	<link rel="stylesheet" type="text/css" href="css/photo.css">
</head>
<body>
	<div class="header">
		<h1>----Health----</h1>
		<ul>
      <li><a href="Home.php"><strong>| Home</strong></a> </li>
      <li><a href="login.php"><strong>| login</strong></a></li>
      <li><a href="Medical.staff.php"><strong>| Medical staff</strong></a></li>
      <li><a href="Patient.php"><strong>| Patient platform</strong></a></li>
      <li><a href="https://nunm.edu"><strong>| Natural Medicine</strong></a></li>
      <li><a href="contact.php"><strong>| Contact Us</strong></a> </li>
      <li><a href="About.php"><strong>| About</strong></a></li>
      
    </ul>	
	</div>
	<div class="para">
		<h2>What is endometriosis?</h2>
		<p><strong>Endometriosis is the abnormal growth of endometrial tissue similar to that which lines the interior of the uterus, but in a location outside of the uterus. Endometrial tissue is shed each month during menstruation. Areas of endometrial tissue found in ectopic locations are called endometrial implants. These lesions are most commonly found on the ovaries, the Fallopian tubes, the surface of the uterus, the bowel, and on the membrane lining of the pelvic cavity (i.e. the peritoneum). They are less commonly found to involve the vagina, cervix, and bladder. Rarely, endometriosis can occur outside the pelvis. Endometriosis has been reported in the liver, brain, lung, and old surgical scars. Endometrial implants, while they may become problematic, are usually benign (i.e. non-cancerous).</strong> </p>
		
	</div>
		    <!-- footer-->
		<div class="foter" >
			<center>
				<p>Copyright &copy; Lifestyle Store. All Rights Reserved | Contact Us: +91 9000000000.</p> 
			</center>	
			
		</div>


</body>
</html>