<!DOCTYPE html>
<html>
<head>
	<title>Heart</title>
	<link rel="stylesheet" type="text/css" href="css/heart.css">
</head>
<body>

	<div>
		<img src="images/heartp.jpg" class="photo">
	</div>
	<h2>Apollo Heart Institute Expertise :</h2>
	<p>
		The Apollo Heart Institutes are regarded as one of the best heart hospitals in India, performing a multitude of treatments and procedures in cardiology and cardiothoracic surgery. The scorecard shows an unmatched record of over 1,52,000 cardiac and cardiothoracic surgeries.<br>

		Our team of cardiologists and cardiothoracic surgeons are trained at the top institutes in India and abroad and are completely dedicated to the treatment for coronary heart diseases. Our pioneering work for the prevention and treatment of cardiac diseases has led to the achievement of better outcomes and improved quality of life for thousands of cardiac patients who visit us each year with complex heart problems. Apollo Hospitals has a team led by the best Cardiologists in India and our advanced infrastructure supports the complex nature of the cardiac care provided. Third generation Cath Labs, Cardiac Critical Care Units and Intensive Care Units support our experienced cardiologists and post-operative care teams, making us the most sought-after Cardiology hospital in India.</p><br><br>
		<h2>Highlights</h2><br>
		<p>
		We have vast experience in the most complicated coronary artery bypass surgery, surgery for all types of valvular heart diseases, paediatric heart surgery, adult and paediatric heart transplantation with success rates comparable to international standards. We have been rated as the best heart surgery hospitals in India time and again through various prestigious surveys. Over 99.6% of our cardiac bypass surgeries are Beating Heart surgeries which ensure quicker and easier post-operative recovery. Our cardiologists are pioneers in Coronary Artery Stenting, Laser Angioplasty and in techniques as advanced as Percutaneous Transluminal Septal Myocardial Ablation. Our heart transplantation programme is one of the most successful in the country.<br><br><br><br><br>
		</p>
			

		<div class="foter" >
			<center>
				<p>Copyright &copy; Lifestyle Store. All Rights Reserved | Contact Us: +91 9000000000.</p> 
			</center>	
			
		</div>		

</body>
</html>